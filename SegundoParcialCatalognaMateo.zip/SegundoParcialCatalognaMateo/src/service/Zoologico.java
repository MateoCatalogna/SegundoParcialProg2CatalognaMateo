
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import model.Animal;
import model.TipoAlimentacion;


public class Zoologico<T extends CSVSerializable> {
    
    private List<T> items = new ArrayList<>();

    public List<T> getItems() {
        return items;
    }
    
    
    
    public void agregar(T item) {
        if(item == null){
            throw new IllegalArgumentException("No se deben almacenar nulos");
        }
        items.add(item);
    }
    
    public T obtener(int indice) {
        validarIndice(indice);
        return items.get(indice);
        
    }
    
    public void eliminar(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for(T item : items){
            if(criterio.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }
    
    public void OrdenamientoNatural(){
         items.sort(null);
    }
    
    
    public void ordenar(Comparator<T> criterio){
        items.sort(criterio);
    }

    
    public void guardarEnArchivo(String nombreArchivo) {
        try(FileOutputStream archivo = new FileOutputStream(nombreArchivo);
            ObjectOutputStream salida = new ObjectOutputStream(archivo)){
            salida.writeObject(items);
        } catch (IOException ex){   
            System.out.println(ex.getMessage());
        }
    }
    
    public List<T> cargarDesdeArchivo(String nombreArchivo) {
        List<T> toReturn = new ArrayList<>();
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(nombreArchivo))){

            toReturn = (List<T>) input.readObject();
            items = toReturn;
        } catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        return toReturn;    
    }
    
    private static void validarOCrearArchivo(String path) {
        File archivo = new File(path);
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe");
            } else {
                archivo.createNewFile();
                System.out.println("Se creó el archivo");
            }
        } catch (IOException ex) {
            System.out.println("Error al crear el archivo: " + ex.getMessage());
        }
    }
    
    public void guardarEnCSV(List<T> lista, String path) {
        validarOCrearArchivo(path);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,especie,alimentacion\n");
            for (T elemento : lista) {
                bw.write(elemento.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println("Error al escribir en el archivo: " + ex.getMessage());
        }
    }
    
    public void cargarDesdeCSV(String path) {
        List<T> toReturn = new ArrayList<>();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                if (linea.endsWith("\n")) {
                    linea = linea.substring(0, linea.length() - 1);
                }
                Animal animal = Animal.fromCSV(linea);
                toReturn.add((T)animal);
            }
        } catch (IOException ex) {
            System.out.println("Error al leer el archivo: " + ex.getMessage());
        }
    }

    
    // metodo para hacer test 
    public void paraCadaElemento(Consumer<? super T> accion){
        for(T item : items){
            accion.accept(item);
        }
    }


    
    
    

    
    
    private void validarIndice(int indice){
        if(indice < 0 || indice > items.size()){
            throw new IndexOutOfBoundsException("indice invalido");
        }
    }
    
    
}
