
package model;


public enum TipoAlimentacion {
    
    CARNIVORO,
    HERBIVORO,
    OMNIVORO,
    INSECTIVORO;
}
