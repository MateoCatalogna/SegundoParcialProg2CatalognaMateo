
package model;

import java.io.Serializable;
import service.CSVSerializable;


public class Animal implements Comparable<Animal>, Serializable, CSVSerializable {
    
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    @Override
    public int compareTo(Animal anotherAnimal) {
        return Integer.compare(this.id, anotherAnimal.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion;
    }

    public static Animal fromCSV(String csv) {
        String[] datos = csv.split(",");
        return new Animal(
                Integer.parseInt(datos[0]),
                datos[1],
                datos[2],
                TipoAlimentacion.valueOf(datos[3])
        );
    }

    
    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    public String getNombre() {
        return nombre;
    }
    
    
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof TipoAlimentacion t){
            return alimentacion.equals(t);
        }
        return false;
    }
    
}
